# Get your API Key: https://platform.openai.com/settings/organization/api-keys
OPENAI_API_KEY = "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"
LOG_ANALYTICS_WORKSPACE_ID = "60c7f53e-249a-4077-b68e-55a4ae877d7c"